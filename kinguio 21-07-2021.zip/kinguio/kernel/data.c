unsigned char dv_num;
unsigned int dv_uid;
unsigned long  kernelmouse;

int tmpnam;

