#include <mm.h>
#include <gui.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>

#include <data.h>

#include <i965.h>


#define TASK_BARRA 36

#define SSE_MMREG_SIZE 16


extern char cursor18x18[18*20];
extern void copymem(void *s1, const void *s2, unsigned long n);

extern void *sse_memcpy(void * s1, const void * s2, size_t len);

WINDOW *w;
PAINT *paint, *paint_ready_queue;

extern mouse_t *mouse;
unsigned long gid;

void window_add(unsigned long addr) {

	PAINT *new = (PAINT*) (addr + 0x1000 - 32);
	w = (WINDOW*) addr;
	
	while(paint_ready_queue->spinlock);
	paint_ready_queue->spinlock++;


	// tmp aponta para inicio da lista
    	PAINT *tmp = paint_ready_queue;
    	// verificar se ja esta registrada
    	while (tmp) {
    	
    		if(tmp->w == addr)
    		{
    			paint_ready_queue->spinlock = 0;
    			return;
    		}
    	
    		tmp = tmp->next;
    	}
    	
    	memset(new, 0, 32);
	new->w = addr;
	new->next = 0;
	
	w->gid = gid ++; 
    	
    	
    	tmp = paint_ready_queue;
    	while (tmp->next) {
    	
    		tmp = tmp->next;
    	}
    	
    	tmp->next = new;
    	
    	paint_ready_queue->spinlock = 0;
}

void window_foco(unsigned long addr) {
	
	while(paint_ready_queue->spinlock);
	paint_ready_queue->spinlock++;

	// tmp aponta para inicio da lista
    	PAINT *tmp = paint_ready_queue;
    	PAINT *pre = tmp;
    	while (tmp) {
    		
    		if(tmp->w == addr) {
    			
    			if(tmp->next != 0){
    			
    				
    				pre->next = tmp->next;
    				tmp->next = 0;
    				pre = paint_ready_queue;
    				while (pre->next) {
    				
    					pre = pre->next;
    				}
    	
    				pre->next = tmp;
    			}
    		
    			break;
    		}
    		pre = tmp;
    		tmp = tmp->next;
    	}
    	
    	paint_ready_queue->spinlock = 0;
}

void paint_desktop(void *bankbuffer) {

	while(paint_ready_queue->spinlock);
	paint_ready_queue->spinlock++;

	paint = paint_ready_queue->next;
	while(paint){
	if(paint->w != 0) {
	
	
		w = (WINDOW*) paint->w;
		
		while(w->spinlock);
		w->spinlock++;
		
		
		unsigned long start  = (unsigned long) &w->start;
		unsigned long zbuf  = ( unsigned long) bankbuffer;
		
		long y =  w->pos_y;
		long x =  w->pos_x;
		
		long pos = ((w->pos_y * gui->pixels_per_scan_line) + w->pos_x) << 2;//*4;
		long width = w->width;
		long height = w->height;
		
		long len = width;
		
		if( (x + width) > gui->pixels_per_scan_line ) {
		
			len = width - ((x + width) - gui->pixels_per_scan_line );
			
		
		}
		
		
		w->spinlock = 0;
		
		
		if( x > gui->pixels_per_scan_line ) {
			paint = paint->next;
			continue;
		}
  		
		
		for(int i=0; i < height; i++) {
		
				unsigned char *src = (unsigned char *) (start + (i*(width << 2)));
				unsigned char *dst = (unsigned char *) (zbuf + (i*(gui->pixels_per_scan_line << 2)) + pos);
				// alinhar 
				if( (((unsigned long int)dst)%SSE_MMREG_SIZE) != 0 )  {
         			unsigned long ajust = ((unsigned long)dst)/ SSE_MMREG_SIZE;
  					ajust *= SSE_MMREG_SIZE;
  		
  					int n = (((unsigned long)dst) - ajust);
  					dst += (SSE_MMREG_SIZE-n);
  					
         		}
         		
         		
         		if (w->gid != 0) {
         			if( (i + y) < (gui->vertical_resolution - TASK_BARRA)){
         			
         				sse_memcpy( dst, src, len << 2);
         			}
         		} else {
         			if(i < gui->vertical_resolution) {
         				sse_memcpy( dst, src, len << 2);
         			}
         		}
         		
         	}
       }
       	paint = paint->next;
       }


	paint_ready_queue->spinlock = 0;
}


extern void DrawMouse(unsigned int color, unsigned int *buffer,void *MouseBuffer);
void paint_cursor(unsigned char *zbuf, WINDOW *addr) {

		if(gtt->INTEL) return;
		
		w = (WINDOW*) addr;
		
		//unsigned long start  = (unsigned long) &w->start;
		
		w->pos_y = mouse->y;
		w->pos_x = mouse->x;

		const char *font_data = (const char*) cursor18x18;
		unsigned int mask;

		for(int t=0;t < w->height;t++) {
		
		
			for(int i= 0;i < w->width ;i ++)
			{
			
				mask = font_data[i+ (t*w->width)];
			
               	      	if(mask == 1) {
               	        	put_pixel_buff(w->pos_x + i, w->pos_y + t, -1, zbuf);
               	        
               	      	}else if( mask == 2){
               	      		put_pixel_buff(w->pos_x + i, w->pos_y + t, 0x101020, zbuf);
               	      	}
                       
	
			}
			
		} 

}


extern int launcher;
int screan_spin_lock;
void screen_refresh()
{

	screan_spin_lock = 0;

	WINDOW *mouseaddr;

	cli();
	alloc_pages(0, 1024*4, (unsigned long *)&gui->bank_buffer);
	alloc_pages(0, 1, (unsigned long *)&paint);
	alloc_pages(0, 4, (unsigned long *)&mouseaddr);
	sti();
	
	
	memset(paint, 0,sizeof(PAINT));
	paint_ready_queue = paint;

	launcher = 0;

	unsigned char *vram = ( unsigned char*)((long)gui->virtual_buffer);
	unsigned char *zbuf  = ( unsigned char*)((long)gui->bank_buffer);
	
	unsigned int len = gui->width * (gui->height) * (gui->bpp/8);
	
	memset(zbuf, 0,len);
	
	
	mouseaddr->width = 18;
	mouseaddr->height = 20;

    	for (;;){
         
         	paint_desktop(zbuf);
         	paint_cursor(zbuf,mouseaddr);
         	

		//#if WAIT_FOR_VERTICAL_RETRACE
        	//while ((inportb(0x3DA) & 0x08));
        	//while (!(inportb(0x3DA) & 0x08));
		//#endif
		
  		
  		while(screan_spin_lock);
		screan_spin_lock++;
  		
  		//copymem(vram, zbuf, len);
  		sse_memcpy(vram, zbuf, len);
  		
  		screan_spin_lock = 0;
  		
  	}
  	
} 	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
