#ifndef __IRQ_H
#define __IRQ_H

extern void *fnvetors_handler[24];
void irq_install();


#endif
