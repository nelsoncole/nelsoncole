#ifndef __DELAY_H
#define __DELAY_H

void mdelay(int count);
void udelay(int count);


#endif
