#ifndef __STDDEF_H
#define __STDDEF_H

#include <size_t.h>
#define NULL ((void *)0)

#endif
