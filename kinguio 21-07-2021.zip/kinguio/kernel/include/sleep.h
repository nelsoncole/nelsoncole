#ifndef __SEEP_H
#define __SEEP_H

void sleep(unsigned long ms);
#endif
