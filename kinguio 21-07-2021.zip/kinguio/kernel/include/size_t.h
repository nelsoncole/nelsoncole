
#ifndef __SIZE_T_H
#define __SIZE_T_H

typedef unsigned size_t;


#endif
