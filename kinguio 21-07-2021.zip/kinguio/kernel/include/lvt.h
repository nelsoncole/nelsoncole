#ifndef __LVT_H
#define __LVT_H


void lvt_install();


#endif
