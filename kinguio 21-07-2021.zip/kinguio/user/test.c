#include <stdio.h>
#include <stdlib.h>

#include <math.h>


int main(int argc, char **argv) {

	/*unsigned char *a = (unsigned char*) malloc(0x100000); //1MiB
	int size = 0;
	FILE *f = fopen("ubuntu.ttf","r");
	if(f == NULL) printf("error: fopen: ubuntu.ttf\n");
	else {
	
		fseek(f, 0,SEEK_END);
		size = (int) ftell(f);
		fseek(f, 0,SEEK_SET);
		
		if(size < 0x100000) {
			if(fread(a, 1, size, f) != size) printf("error: fread\n");	
		}
	
		printf("TTF: filesize: %d\n",size);
		
		for(int i=0; i < 0x200; i ++) putchar(a[i]);
	
		putchar('\n');
	}
	
	free(a);
	fclose(f);*/
	
	printf("%lf, %lf\n", sqrt(-5), sqrt(25));
	return 0;
}
