#include <window.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h>

#include <pipe.h>

extern char *pwd;
void main() {
	
	WINDOW *w = window("@~Terminal",100, 20, 400, 540, 0x1f1f2f, 0x101020, -1, 0);
	// register 
	wcl(w);
	
	__asm__ __volatile__("int $0x72"::"d"(3),"D"(stdin)); // foco do teclado

	char *path = malloc(128);

	strcpy(path,"shell.bin\0");
	__asm__ __volatile__("movq %%rax,%%r8;"
	" int $0x72;"
	::"d"(8),"D"(path),"S"(0),"c"(1), "a"(pwd)); // fork
	
	
	for(;;){
	
		fmouse(w);
		
	}
}
