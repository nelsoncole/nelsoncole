#include <window.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#include <data.h>
#include <time.h>

extern void _drawline(int x1, int y1, int x2, int y2, int rgb, WINDOW *w);
extern void update(const char *id, WINDOW *w );

const char *ss[60]={\
"00","01","02","03","04","05","06","07","08","09",
"10","11","12","13","14","15","16","17","18","19",
"20","21","22","23","24","25","26","27","28","29",
"30","31","32","33","34","35","36","37","38","39",
"40","41","42","43","44","45","46","47","48","49",
"50","51","52","53","54","55","56","57","58","59"
};

extern int wp(char *name);
extern char *pwd;
extern void put(int c, int x, int y, WINDOW *w);
extern int read_sector(int dev,unsigned count,unsigned long long addr,void *buffer);
int main()
{


	time_t	timer;
	struct tm *h;
	char s[32];
	memset(s,0,32);
	
	int min = 0;
	
	h = gmtime(&timer);
	sprintf(s, "%s:%s",ss[h->tm_hour], ss[h->tm_min]);

	int tx1, ty1, tx2, ty2;
	int fx1, fy1, fx2, fy2;
	int ex1, ey1, ex2, ey2;

	WINDOW *w = (WINDOW*) (__window);
	memset((char*)&w->start,0, 0x400000-0x1000);
	
	w->width = w->rx;
	w->height = w->ry;
	w->pos_x = 0;
	w->pos_y = 0;
	
	
	w->area_width = w->width;
	w->area_height = w->height;
	w->area_x = 0;
	w->area_y = 0;
	
	//init font
	w->font.x = 8;
	w->font.y = 16;
	w->font.fg_color = 0;//0xfcfc00;
	w->font.bg_color = 0xe0e0e0;
	w->font.buf = (unsigned long)font8x16;
	
	drawline(w->pos_x ,w->pos_y, w->width, w->height, 0xFF00A0A0,w);
	
	wp("w.ppm");
	// barra
	drawline(w->pos_x ,w->height-36, w->width, 36, 0xe0e0e0,w);
	
	fx1 = w->pos_x + 4;
	fy1 = w->height-34;
	fx2 = 32;
	fy2 = 28;
	//button("Arquivos",fx1, fy1, fx2, fy2, 0x101020,0xe0e0e0, w );
	
	tx1 = w->pos_x + 8 + fx2;
	ty1 = w->height-34;
	tx2 = 32;
	ty2 = 28;
	//button("Terminal",tx1, ty1, tx2, ty2, 0x101020,0xe0e0e0, w );
	
	ex1 = w->pos_x + 12 + fx2 + tx2;
	ey1 = w->height-34;
	ex2 = 32;
	ey2 = 28;
	//button("Edit",mx1, my1, mx2, my2, 0x202020,0xe0e0e0, w );
	
	// Relogio
	//button(s,w->width - 100, w->height-24, 10*8, 20,-1,0x80808080, w );
	
	char *tdata = malloc(0x2000);
	char *fdata = malloc(0x2000);
	char *edata = malloc(0x2000);
	char *data = malloc(0x10000);
	
	FILE *f = fopen("console.bmp","r");
	if(f){
	
		fseek(f,0,SEEK_END);
		int s = ftell(f);
		rewind(f);
	
		fread(tdata,1,s,f);
		
		
		BitMAP( tdata, tx1,ty1, 0xe0e0e0, w);
	
		fclose(f);
	}else printf("open error\n");
	
	
	f = fopen("folder.bmp","r");
	if(f){
	
		fseek(f,0,SEEK_END);
		int s = ftell(f);
		rewind(f);
	
		fread(fdata,1,s,f);
		
		BitMAP( fdata, fx1,fy1, 0xe0e0e0, w);
	
		fclose(f);
	}else printf("open error\n");
	
	f = fopen("edit.bmp","r");
	if(f){
	
		fseek(f,0,SEEK_END);
		int s = ftell(f);
		rewind(f);
	
		fread(edata,1,s,f);
		
		BitMAP( edata, ex1,ey1, 0xe0e0e0, w);
	
		fclose(f);
	}else printf("open error\n");
	
	/*f = fopen("test.bmp","r");
	if(f){
	
		fseek(f,0,SEEK_END);
		int s = ftell(f);
		rewind(f);
	
		fread(data,1,s,f);
		
		//BitMAP( data, 0, 0, 0xFF00A0A0, w);
	
		fclose(f);
	}else printf("open error\n");
	*/
	// register 
	wcl(w);
	
	
	char *path = malloc(128);
	
	int fl = 0, count = 0;
	int fs = 0;
	int fe = 0;	
	
	//put('A', 20, 20, w);
	
	unsigned long id = 0;
	
	for(;;){
		__asm__ __volatile__("pause": : :"memory");
	
		if(mouse->b&0x1) 
		{
			while(mouse->b&0x1)__asm__ __volatile__("pause": : :"memory"); // espera soltar
			count++;
			
			if(mouse->x > tx1 && mouse->y > ty1 &&  mouse->x < (tx1+tx2) && mouse->y < (ty1 + ty2) && count == 1 ) {
			
				//button("Terminal",tx1, ty1, tx2, ty2,-1,0x808080, w );
				BitMAP( tdata, tx1,ty1, 0, w);
			
				if(fl == 0) {
					id ++;
					strcpy(path,"term.bin\0");
					__asm__ __volatile__( "movq %%rax,%%r8;"
					" int $0x72;"
					::"d"(8),"D"(path),"S"(id),"c"(2), "a"(pwd)); // execute
					
					fl = id;
				}else {
				
					__asm__ __volatile__("int $0x72"::"d"(8),"S"(fl),"c"(5));
				}	
				
				BitMAP( fdata, fx1,fy1, 0xe0e0e0, w);	
				BitMAP( edata, ex1,ey1, 0xe0e0e0, w);
			}
			
			if(mouse->x > fx1 && mouse->y > fy1 &&  mouse->x < (fx1+fx2) && mouse->y < (fy1 + fy2) && count == 1 ) {
			
				//button("Arquivos",fx1, fy1, fx2, fy2,-1, 0x808080, w );
				BitMAP( fdata, fx1,fy1, 0, w);
				
				if(fs == 0) {
					id ++;
					strcpy(path,"explore.bin\0");
					__asm__ __volatile__( "movq %%rax,%%r8;"
					" int $0x72;"
					::"d"(8),"D"(path),"S"(id),"c"(2), "a"(pwd)); // execute
					fs = id;
				}else {
				
					__asm__ __volatile__("int $0x72"::"d"(8),"S"(fs),"c"(5));
				}
			
				BitMAP( tdata, tx1,ty1, 0xe0e0e0, w);
				BitMAP( edata, ex1,ey1, 0xe0e0e0, w);
						
			}
			
			if(mouse->x > ex1 && mouse->y > ey1 &&  mouse->x < (ex1+ex2) && mouse->y < (ey1 + ey2) && count == 1 ) {
			
				//button("Edit",mx1, my1, mx2, my2,-1, 0x808080, w );
				BitMAP( edata, ex1,ey1, 0, w);
				
				if(fe == 0) {
					id ++;
					strcpy(path,"editor.bin\0");
					__asm__ __volatile__( "movq %%rax,%%r8;"
					" int $0x72;"
					::"d"(8),"D"(path),"S"(id),"c"(2), "a"(pwd)); // execute
				
					fe = id;
				}else {
				
					__asm__ __volatile__("int $0x72"::"d"(8),"S"(fe),"c"(5));
				}
			
				BitMAP( tdata, tx1,ty1, 0xe0e0e0, w);
				BitMAP( fdata, fx1,fy1, 0xe0e0e0, w);
				
						
			}
			
			count = 0;

		}
	
	
		if(min != h->tm_min) {
			min = h->tm_min;
			sprintf(s, "%s:%s",ss[h->tm_hour], ss[h->tm_min]);
			update(s, w );
		}
		
		__asm__ __volatile__ ("pause;");
		
	}

	return 0;
}
