#ifndef __WINDOW_H
#define __WINDOW_H

#include "gui.h"

#include <data.h>


#define WMENU_SIZE 24
#define WBART_SIZE 24
#define WROD_SIZE 16

#define TYPE_MENUBOX 1
#define TYPE_EDITBOX 2
#define TYPE_LISTBOX 3
#define TYPE_FILE_LISTBOX 4

#define MSG_MAX 10

extern int getkey();
extern unsigned long __window;

typedef struct _font {
	int x;
	int y;
	unsigned int fg_color;
	unsigned int bg_color;
	unsigned long buf;
}__attribute__ ((packed)) font_t;

typedef struct __WINDOW {
	unsigned int	spinlock;
	unsigned int	rx, ry, bpp, scanline;
	unsigned int 	height, width;
	unsigned int 	pos_y, pos_x;
	
	unsigned int 	area_height, area_width;
	unsigned int 	area_y, area_x;
	
	unsigned int  	fg, bg, text_fg;
	
	unsigned int 	cy, cx;
	font_t		font;
	
	unsigned int	style;
	unsigned int	gid;
	char		rsv[4096 - 104];
	unsigned int 	start;
	
}__attribute__ ((packed)) WINDOW;


typedef struct _HANDLE {
	unsigned int 	type;
	unsigned int 	x, y;
	unsigned int 	width, height;
	 
	unsigned int	id, flag;
	unsigned int 	fg, bg;
	unsigned int 	cx, cy; 
	unsigned int	offset;
	unsigned int 	len;
	unsigned int 	bytes;
	unsigned long	addr;
	unsigned long	w;
}__attribute__ ((packed)) HANDLE_T;


typedef struct _SUBMENU {
	unsigned int id;
	unsigned int style;
	char 	name[32];
}__attribute__ ((packed)) SUBMENU_T;
typedef struct _MENU {
	unsigned int 	type;
	unsigned int 	x, y;
	unsigned int 	width, height;
	
	unsigned int	id, flag;
	unsigned int 	fg, bg;
	unsigned int	count;
	unsigned long	w;
	char		name[32];
	SUBMENU_T 	sub[32];
}__attribute__ ((packed)) MENU_T; 


typedef struct _MSG {
	unsigned int 	offset1, offset2;
	unsigned int 	size;
	unsigned int	buf[MSG_MAX];
}__attribute__ ((packed)) MSG_T; 


void drawline(int x1, int y1, int x2, int y2, int rgb, WINDOW *w);
void drawrect(int x, int y, int width, int height, int rgb, WINDOW *w);
void drawchar( unsigned short int c, int cx, int cy, unsigned int fg, unsigned int bg, struct _font *font, WINDOW *w);
void drawstring( const char *str, int cx, int cy, unsigned int fg, unsigned int bg, struct _font *font, WINDOW *w);
void drawstring_trans( const char *str, int cx, int cy, unsigned int fg, unsigned int bg, struct _font *font, WINDOW *w);

void drawchar_trans( unsigned short int c, int cx, int cy, unsigned int fg, unsigned int bg, struct _font *font, WINDOW *w);

WINDOW *window(const char *title,int x, int y, int width, int height,int fg, int bg, int tfg , int style);
void wcl(WINDOW *w);

void __window_clear(WINDOW *w);
int __window_putchar( unsigned short int c);
void __window_puts(char* s);

int BitMAP( void *Data, int X, int Y, int bg, WINDOW *w);
int BitMAP2( void *Data, int X, int Y, int fg, int bg, WINDOW *w);


void color(int rgb);


HANDLE_T *editbox(int x, int y, int width, int height, int fg, int bg, WINDOW *w, unsigned int id);
int m_edit(HANDLE_T *obj);
void update_editbox(HANDLE_T *obj);

void fmouse(WINDOW *w);

void menubox(WINDOW *w, MENU_T **menu, const char *name, int x1, int y1, int x2, int y2, unsigned int id);
int menumotor(MENU_T *menu);
int submenubox(MENU_T *menu, const char *name, unsigned int id);

int register_obj(void *obj);
int obj_process(int x, int y);
void update_objs(WINDOW *w);
int obj_focprocess();
int init_process(HANDLE_T *o);


int getmsg(int msg, WINDOW *w);

void msg_init();
void msg_write (int id);
int msg_read();

int dialogbox(WINDOW *w, void *buf);

void border(int top, int bottom, int left, int right, WINDOW *w);


HANDLE_T *file_listbox(int x, int y, int width, int height, int fg, int bg, WINDOW *w, unsigned int id);
int m_file_list(HANDLE_T *obj);

#endif
