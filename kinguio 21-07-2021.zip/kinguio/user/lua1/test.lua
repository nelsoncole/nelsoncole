$debug


function somaP (x1,y1,x2,y2)
  return x1+x2, y1+y2
end

function norma (x,y)
  return x*x+y*y
end

function retorno_multiplo ()
 print (norma(somaP(2,3,4,5)))
end

