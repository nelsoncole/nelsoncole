k,v=nextvar(k)
while k do
 print(k)
 k,v=nextvar(k)
end
