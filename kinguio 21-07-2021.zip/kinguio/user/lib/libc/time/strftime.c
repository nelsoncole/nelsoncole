#include <time.h>

size_t strftime(char * restrict s, size_t maxsize,
const char * restrict format, const struct tm * restrict timeptr)
{

	return (0);

}
