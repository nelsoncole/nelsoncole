#include <time.h>


time_t time(time_t *timer) 
{

	return (0);

}
