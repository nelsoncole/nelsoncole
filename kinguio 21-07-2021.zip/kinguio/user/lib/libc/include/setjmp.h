#ifndef __SETJMP_H
#define __SETJMP_H

#define _JBLEN (68/2)  /* room for 68 32-bit regs */

typedef	int jmp_buf[64];


extern int setjmp(jmp_buf env);
extern void longjmp(jmp_buf env, int val);

#endif
