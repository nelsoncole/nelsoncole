#ifndef __TGMATH_H
#define __TGMATH_H


#define	fabs(__x) (0)
#define	fmod(__x, __y) (0)

#endif
