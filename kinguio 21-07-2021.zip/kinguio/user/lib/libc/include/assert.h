#ifndef __ASSERT_H
#define __ASSERT_H


#define NDEBUG 0
//void assert(scalar expression);

#endif
