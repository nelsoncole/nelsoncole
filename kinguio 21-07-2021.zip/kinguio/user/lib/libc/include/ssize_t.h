
#ifndef __SSIZE_T_H
#define __SSIZE_T_H

typedef int ssize_t;


#endif
