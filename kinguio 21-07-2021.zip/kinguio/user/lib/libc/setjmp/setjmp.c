#include <setjmp.h>
#include <stdio.h>

int setjmp(jmp_buf env)
{
	printf("panic: setjmp() ");
	
	for(int i=0; i < 64; i++) putchar(env[i]);
	//for(;;);
	return -1;
}
void longjmp(jmp_buf env, int val) 
{
	printf("panic: longjmp");
	for(;;);

}
