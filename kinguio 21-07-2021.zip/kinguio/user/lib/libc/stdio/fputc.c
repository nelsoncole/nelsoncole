#include <stdio.h>


int fputc (int ch, FILE *fp) 
{
	return putc (ch,fp);
}
