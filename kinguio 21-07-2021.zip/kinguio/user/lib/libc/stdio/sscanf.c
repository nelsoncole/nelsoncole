#include <stdio.h>


int sscanf(const char *s,const char *fmt, ...)
{

	printf("panic: sscanf()\n");
	for(;;);	
	
    	return (0);

}
