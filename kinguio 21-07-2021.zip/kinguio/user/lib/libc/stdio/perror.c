#include <stdio.h>

void perror(const char *s)
{
	puts(s);
	
}
