#include <stdio.h>


int ferror (FILE *fp )
{
	return 0;
}
