#include <stdio.h>

int fgetc (FILE *fp)
{	
	return getc (fp);

}

