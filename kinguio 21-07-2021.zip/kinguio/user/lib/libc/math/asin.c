#include <math.h>



double asin(double x)
{
	return 0;
}
