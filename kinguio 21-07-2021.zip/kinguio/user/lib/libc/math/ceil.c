#include <math.h>


double ceil(double x)
{
	return 0;
}
