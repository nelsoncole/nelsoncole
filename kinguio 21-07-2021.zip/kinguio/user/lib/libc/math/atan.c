#include <math.h>



double atan(double x)
{
	return 0;
}
