#include <math.h>



double cos(double x)
{
	return 0;
}
