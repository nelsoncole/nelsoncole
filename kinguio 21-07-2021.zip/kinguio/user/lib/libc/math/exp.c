#include <math.h>


double exp(double x)
{
	return pow(2.71828182846, x);
}
