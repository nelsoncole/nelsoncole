#include <math.h>

double floor(double x)
{
	return 0;
}
