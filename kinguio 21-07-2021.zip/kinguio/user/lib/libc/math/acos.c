#include <math.h>



double acos(double x)
{
	return 0;
}
