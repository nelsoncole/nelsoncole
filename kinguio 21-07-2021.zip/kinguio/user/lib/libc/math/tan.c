#include <math.h>



double tan(double x)
{
	return 0;
}
