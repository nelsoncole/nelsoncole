#include <math.h>

double log10(double x)
{

	return 0;

}

double log(double x)
{
	return 0;
}


double ldexp(double x, int exp)
{
	return 0;
}

double frexp(double value, int *exp)
{
	return 0;
}

double atan2(double y, double x)
{
	return 0;
}
