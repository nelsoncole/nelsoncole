
#include <stdlib.h>

#undef        abs


int abs ( int j){
	
	return (j < 0 ? -j : j);
}

