#include <stdlib.h>


int rand(void)
{
	
	return 1;

}
