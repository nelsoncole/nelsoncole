#include <stdlib.h>


void srand(unsigned int seed)
{

}
