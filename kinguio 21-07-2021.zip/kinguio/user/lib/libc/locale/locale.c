#include <locale.h>

char *setlocale(int a, const char * b)
{

	return 0;
}
