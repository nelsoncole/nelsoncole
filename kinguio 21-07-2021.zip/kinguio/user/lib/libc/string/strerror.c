#include <string.h>
#include <stdio.h>

char *strerror(int errnum){

	printf("strerrorr\n");
	for(;;);
	return 0;
}
