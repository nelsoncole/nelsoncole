#include <string.h>

int strcoll(const char *a, const char *b)
{
  return strcmp (a, b);
}
