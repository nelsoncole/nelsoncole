#ifndef __PIC_H
#define __PIC_H


void pic_install(void);


#endif
