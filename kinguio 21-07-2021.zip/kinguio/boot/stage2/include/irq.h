#ifndef __IRQ_H
#define __IRQ_H

void irq_enable(int irq);
void irq_disable(int irq);

#endif
