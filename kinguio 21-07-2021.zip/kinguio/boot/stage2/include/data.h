#ifndef __DATA_H
#define __DATA_H

#define PAGING_ADDR 0x101000

extern unsigned char dv_num;
extern unsigned int dv_uid;
extern unsigned int heap;

#endif
