Driver USB em implementação
